import 'package:flutter/material.dart';

class StarMarket extends StatefulWidget {
  const StarMarket({super.key});

  @override
  State<StarMarket> createState() => _StarMarketState();
}

class _StarMarketState extends State<StarMarket> {
  // بيانات المنتجات الحية لمحاكاة متجر إعجاب الذكي
  final List<Map<String, String>> _products = [
    {'title': 'اشتراك إعجاب بلس النيوني', 'price': '٩٩ $', 'category': 'خدمات مميزة', 'icon': '💎'},
    {'title': 'حزمة نقاط الدعم الذهبية', 'price': '٤٩ $', 'category': 'ترقية الحساب', 'icon': '🪙'},
    {'title': 'شارة التوثيق المضيئة 👍', 'price': '١٥٠ $', 'category': 'حزم النجوم', 'icon': '👑'},
    {'title': 'تذكرة البث الإمبراطورية', 'price': '٢٩ $', 'category': 'فعاليات حية', 'icon': '🎟️'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D0D),
        elevation: 0,
        title: const Text(
          'استكشاف المتجر',
          style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
        ),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: _products.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.8,
          crossAxisSpacing: 14,
          mainAxisSpacing: 14,
        ),
        itemBuilder: (context, index) {
          final product = _products[index];

          return Container(
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.03),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // منطقة الشعار الأيقوني للمنتج بالخلفية المضيئة
                Expanded(
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.blueAccent.withOpacity(0.05),
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                    ),
                    child: Center(
                      child: Text(
                        product['icon']!,
                        style: const TextStyle(fontSize: 45),
                      ),
                    ),
                  ),
                ),
                // تفاصيل ونصوص المنتج بأسفل البطاقة
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        product['category']!,
                        style: const TextStyle(color: Colors.blueAccent, fontSize: 11, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        product['title']!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            product['price']!,
                            style: const TextStyle(color: Colors.greenAccent, fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          // زر الشراء التفاعلي النيوني الصغير
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: Colors.blueAccent.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.add_shopping_cart, color: Colors.blueAccent, size: 18),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
