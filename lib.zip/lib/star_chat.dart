import 'package:flutter/material.dart';

class StarChat extends StatefulWidget {
  const StarChat({super.key});

  @override
  State<StarChat> createState() => _StarChatState();
}

class _StarChatState extends State<StarChat> {
  // بيانات تجريبية حية ومطورة تحاكي الواجهة الحقيقية للتطبيق
  final List<Map<String, String>> _chats = [
    {'name': 'أحمد محمد', 'message': 'مرحباً بك في تطبيق إعجاب الجديد!', 'time': '١٢:٠٥ م', 'unread': '١'},
    {'name': 'مريم علي', 'message': 'تم إرسال العقد البرمجي بنجاح 👍', 'time': '١١:٤٠ ص', 'unread': '٠'},
    {'name': 'فريق الدعم الفني', 'message': 'مستعدون لإطلاق خوادم فيربيس', 'time': 'أمس', 'unread': '٢'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D0D),
        elevation: 0,
        title: const Text(
          'الرسائل',
          style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.blueAccent),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
        itemCount: _chats.length,
        itemCount: _chats.length,
        itemBuilder: (context, index) {
          final chat = _chats[index];
          final bool hasUnread = chat['unread'] != '٠';

          return Container(
            margin: const EdgeInsets.only(bottom: 12.0),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.03),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.all(12),
              leading: Stack(
                children: [
                  CircleAvatar(
                    radius: 26,
                    backgroundColor: Colors.blueAccent.withOpacity(0.2),
                    child: Text(
                      chat['name']![0],
                      style: const TextStyle(color: Colors.blueAccent, fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                  // نقطة النشاط النيونية الخضراء الذكية (Active Status)
                  Positioned(
                    bottom: 0,
                    right: 2,
                    child: Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.greenAccent,
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF0D0D0D), width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.greenAccent.withOpacity(0.6),
                            blurRadius: 4,
                            spreadRadius: 1,
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              title: Text(
                chat['name']!,
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 6.0),
                child: Text(
                  chat['message']!,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: hasUnread ? Colors.white70 : Colors.white38, fontSize: 13),
                ),
              ),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    chat['time']!,
                    style: const TextStyle(color: Colors.white38, fontSize: 11),
                  ),
                  if (hasUnread) ...[
                    const SizedBox(height: 8),
                    // عداد الرسائل غير المقروءة النيوني الأزرق الفخم
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.blueAccent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        chat['unread']!,
                        style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ],
              ),
              onTap: () {
                // سيتم هنا لاحقاً ربط الشات الفعلي بالسيرفر لنقل الرسائل بالثانية
              },
            ),
          );
        },
      ),
    );
  }
}
