import 'package:flutter/material.dart';

class NajmaReels extends StatefulWidget {
  const NajmaReels({super.key});

  @override
  State<NajmaReels> createState() => _NajmaReelsState();
}

class _NajmaReelsState extends State<NajmaReels> {
  // بيانات حية تحاكي نظام التغذية التفاعلي للريلز (Reels Feed)
  final List<Map<String, dynamic>> _reels = [
    {
      'username': '@ahmed_creative',
      'caption': 'أول تجربة برمجية لتطبيق إعجاب الجديد! القادم مذهل 🚀🔥',
      'likes': '١٢.٥ ألف',
      'comments': '٣٤٠',
      'isLiked': false,
    },
    {
      'username': '@mario_designer',
      'caption': 'تصميم الواجهات السيبربانكية والنيونية الفخمة للتطبيق 👍🎨',
      'likes': '٨.٩ ألف',
      'comments': '١٩٥',
      'isLiked': true,
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: PageView.builder(
        scrollDirection: Axis.vertical,
        itemCount: _reels.length,
        itemBuilder: (context, index) {
          final reel = _reels[index];

          return Stack(
            children: [
              // خلفية تحاكي مشغل الفيديو الكامل (فيديو وهمي فخم ومتحرك لحين ربط السيرفر)
              Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.blueAccent.withOpacity(0.1),
                      const Color(0xFF0D0D0D),
                    ],
                  ),
                ),
                child: const Center(
                  child: Icon(
                    Icons.play_circle_outline,
                    color: Colors.white24,
                    size: 80,
                  ),
                ),
              ),
              // الطبقة الظلية السفلية لحماية النصوص والأسماء (Gradient Overlay)
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.center,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.8),
                      ],
                    ),
                  ),
                ),
              ),
              // أزرار التفاعل الجانبية الفخمة (الإعجاب، التعليقات، المشاركة)
              Positioned(
                bottom: 100,
                right: 16,
                child: Column(
                  children: [
                    // زر الإعجاب المتفاعل الحقيقي
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _reels[index]['isLiked'] = !reel['isLiked'];
                        });
                      },
                      child: Column(
                        children: [
                          Icon(
                            reel['isLiked'] ? Icons.favorite : Icons.favorite_border,
                            color: reel['isLiked'] ? Colors.redAccent : Colors.white,
                            size: 38,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            reel['likes'],
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    // زر التعليقات المضاء
                    Column(
                      children: [
                        const Icon(Icons.mode_comment_outlined, color: Colors.white, size: 35),
                        const SizedBox(height: 6),
                        Text(
                          reel['comments'],
                          style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    // زر المشاركة والإرسال
                    const Column(
                      children: [
                        Icon(Icons.share_outlined, color: Colors.white, size: 35),
                        const SizedBox(height: 6),
                        Text(
                          'مشاركة',
                          style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // نصوص منشئ المحتوى والوصف المكتوب بأسفل الريلز
              Positioned(
                bottom: 40,
                left: 16,
                right: 80,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 18,
                          backgroundColor: Colors.blueAccent.withOpacity(0.3),
                          child: const Text('👍', style: TextStyle(fontSize: 14)),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          reel['username'],
                          style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(width: 12),
                        // زر متابعة نيون فخم جداً
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.blueAccent, width: 1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text(
                            'متابعة',
                            style: TextStyle(color: Colors.blueAccent, fontSize: 11, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      reel['caption'],
                      style: const TextStyle(color: Colors.white90, fontSize: 13, height: 1.4),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
