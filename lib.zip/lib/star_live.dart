import 'package:flutter/material.dart';

class StarLive extends StatefulWidget {
  const StarLive({super.key});

  @override
  State<StarLive> createState() => _StarLiveState();
}

class _StarLiveState extends State<StarLive> {
  // قائمة التعليقات المتدفقة الحية التي تحاكي دردشة البث المباشر الفعلي
  final List<Map<String, String>> _liveComments = [
    {'user': 'خالد العتيبي', 'text': 'ما شاء الله، جودة البث ممتازة وتطبيق إعجاب فخم جداً!'},
    {'user': 'سارة أحمد', 'text': 'الشعار الجديد 👍 نيون ورهيب!'},
    {'user': 'المهندس رامي', 'text': 'مستعدون للتفعيل السحابي الحقيقي 🚀'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // خلفية غامقة ومضيئة تحاكي عدسة الكاميرا الحية والتشغيل السحابي للبث
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.blueAccent.withOpacity(0.15),
                  const Color(0xFF0D0D0D),
                ],
              ),
            ),
            child: const Center(
              child: Icon(Icons.videocam_off_outlined, color: Colors.white12, size: 70),
            ),
          ),
          // الشريط العلوي الحاسم (شارة LIVE حمراء، وعداد المشاهدين النيوني المضاء)
          Positioned(
            top: 50,
            left: 16,
            right: 16,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.redAccent,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        'مباشر',
                        style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.remove_red_eye, color: Colors.blueAccent, size: 14),
                          SizedBox(width: 6),
                          Text(
                            '٢,٥٠٠',
                            style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                // زر الإغلاق والخروج السريع من الغرفة
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white, size: 28),
                  onPressed: () {},
                ),
              ],
            ),
          ),
          // صندوق تجميع دردشة التعليقات الحية المتدفقة بأسفل الشاشة
          Positioned(
            bottom: 40,
            left: 16,
            right: 16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 180,
                  child: ListView.builder(
                    reverse: true,
                    itemCount: _liveComments.length,
                    itemBuilder: (context, index) {
                      final comment = _liveComments[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.03)),
                        ),
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: '${comment['user']}: ',
                                style: const TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold, fontSize: 13),
                              ),
                              TextSpan(
                                text: comment['text']!,
                                style: const TextStyle(color: Colors.whiteEE, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 12),
                // حقل إدخال التعليقات التفاعلي الفوري للمشاهد
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'اكتب تعليقاً حياً...',
                          hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                          filled: true,
                          fillColor: Colors.white.withOpacity(0.04),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(14),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    // زر إرسال الهدايا والتفاعلات النيونية
                    CircleAvatar(
                      radius: 22,
                      backgroundColor: Colors.blueAccent,
                      child: const Icon(Icons.card_giftcard, color: Colors.white, size: 20),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
