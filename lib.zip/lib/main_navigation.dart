import 'package:flutter/material.dart';
import 'package:iejab_app/star_chat.dart';
import 'package:iejab_app/najma_reels.dart';
import 'package:iejab_app/star_live.dart';
import 'package:iejab_app/star_market.dart';
import 'package:iejab_app/starpay_wallet.dart';

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;

  // مصفوفة الصفحات الرئيسية لتطبيق إعجاب
  final List<Widget> _screens = [
    const StarChat(),
    const NajmaReels(),
    const StarLive(),
    const StarMarket(),
    const StarPayWallet(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        height: 75,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.02),
          border: Border(
            top: BorderSide(
              color: Colors.blueAccent.withOpacity(0.15),
              width: 1,
            ),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.transparent,
          selectedItemColor: Colors.blueAccent,
          unselectedItemColor: Colors.white38,
          selectedFontSize: 11,
          unselectedFontSize: 11,
          elevation: 0,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.chat_bubble_outline),
              activeIcon: Icon(Icons.chat_bubble, color: Colors.blueAccent),
              label: 'الدردشة',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.video_collection_outlined),
              activeIcon: Icon(Icons.video_collection, color: Colors.blueAccent),
              label: 'الريلز',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.live_tv_outlined),
              activeIcon: Icon(Icons.live_tv, color: Colors.blueAccent),
              label: 'البث المباشر',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.storefront_outlined),
              activeIcon: Icon(Icons.storefront, color: Colors.blueAccent),
              label: 'المتجر',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet_outlined),
              activeIcon: Icon(Icons.account_balance_wallet, color: Colors.blueAccent),
              label: 'المحفظة',
            ),
          ],
        ),
      ),
    );
  }
}
