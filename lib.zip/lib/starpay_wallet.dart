import 'package:flutter/material.dart';

class StarPayWallet extends StatefulWidget {
  const StarPayWallet({super.key});

  @override
  State<StarPayWallet> createState() => _StarPayWalletState();
}

class _StarPayWalletState extends State<StarPayWallet> {
  // بيانات المحاكاة المالية الحية لمحفظة تطبيق إعجاب
  double _balance = 1250.75;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0D0D0D),
        elevation: 0,
        title: const Text(
          'محفظة StarPay',
          style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // بطاقة الرصيد الرقمية النيونية الفخمة والمضاءة بالكامل
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24.0),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blueAccent, Colors.blueAccent.withOpacity(0.6)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blueAccent.withOpacity(0.2),
                    blurRadius: 20,
                    spreadRadius: 2,
                  )
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'إجمالي الرصيد المتوفر',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '\$ ${_balance.toStringAsFixed(2)}',
                    style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold, letterSpacing: 1),
                  ),
                  const SizedBox(height: 20),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('**** **** **** 7492', style: TextStyle(color: Colors.white60, fontSize: 14, letterSpacing: 2)),
                      Text('StarPay', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, fontStyle: FontStyle.italic)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            // صف أزرار العمليات المالية التفاعلية (شحن، تحويل، سحب)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildActionButton(Icons.add_card, 'شحن رصيد', () {
                  setState(() {
                    _balance += 100.00; // شحن 100 دولار تفاعلياً لتجربة حية
                  });
                }),
                _buildActionButton(Icons.send_rounded, 'تحويل مالي', () {
                  if (_balance >= 50) {
                    setState(() {
                      _balance -= 50.00; // تحويل 50 دولار تفاعلياً لتجربة حية
                    });
                  }
                }),
                _buildActionButton(Icons.payments_outlined, 'سحب نقدي', () {}),
              ],
            ),
            const SizedBox(height: 40),
            // عنوان السجل المالي الأخير
            const Align(
              alignment: Alignment.centerRight,
              child: Text(
                'العمليات الأخيرة',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 16),
            // مربع قائمة كشف الحساب والعمليات المالية الأخيرة
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.02),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.04)),
              ),
              child: Column(
                children: [
                  _buildTransactionItem('شحن عبر البطاقة البنكية', '+\$ 100.00', 'اليوم، ١٢:٠٠ ص', Colors.greenAccent),
                  const Divider(color: Colors.white10),
                  _buildTransactionItem('تحويل إلى صديق', '-\$ 50.00', 'أمس، ٠٩:٣٠ م', Colors.redAccent),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ويدجيت مخصصة لبناء أزرار العمليات المالية التفاعلية بشكل نظيف وموحد
  Widget _buildActionButton(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withOpacity(0.05)),
            ),
            child: Icon(icon, color: Colors.blueAccent, size: 24),
          ),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildTransactionItem(String title, String amount, String date, Color amountColor) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 8),
      leading: CircleAvatar(
        backgroundColor: Colors.white.withOpacity(0.03),
        child: Icon(amountColor == Colors.greenAccent ? Icons.arrow_downward : Icons.arrow_upward, color: amountColor, size: 18),
      ),
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
      subtitle: Text(date, style: const TextStyle(color: Colors.white38, fontSize: 12)),
      trailing: Text(amount, style: TextStyle(color: amountColor, fontSize: 15, fontWeight: FontWeight.bold)),
    );
  }
}
