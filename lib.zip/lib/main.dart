import 'package:flutter/material.dart';
import 'login_screen.dart';

void main() {
  runApp(const IejabApp());
}

class IejabApp extends StatelessWidget {
  const IejabApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'إعجاب',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.blueAccent,
        scaffoldBackgroundColor: const Color(0xFF0D0D0D),
        fontFamily: 'Roboto',
      ),
      home: const LoginScreen(),
    );
  }
}
